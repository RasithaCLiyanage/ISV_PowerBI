const checkAuth = require('../auth/checkAuth');
var mysql = require('mysql');
const {REPORT_TABLE, USER_REPORT_TABLE} = require('../tableNames');


module.exports = async function (context, req) {
  try{
    var auth = req.headers.authorization;//get the Authorization header from the incoming request

    let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
    let result = await checkAuth(idToken); //await the result of our authentication check
    console.log("result", result)
    if(!result){
        throw Error("Invalid token.")
    }
    if (result.roles.includes('Admin.Privilege')) {
        var connection = mysql.createConnection({
          host     : process.env.db_host,
          user     : process.env.db_user,
          password : process.env.db_password,
          database : process.env.database_name,
          multipleStatements: true
        });
      const users = req.body.users;
      const name = req.body.name;
      const powerBiId = req.body.powerBiId;
      const workspaceId = req.body.workspaceId;

      if (users.length) {
        for (const userID of users) {
          const sql_insert = `INSERT INTO ${REPORT_TABLE} (name, powerBiId, workspaceId) VALUES(?,?,?); SET @report_id = LAST_INSERT_ID(); INSERT INTO ${USER_REPORT_TABLE} (userId, reportId) VALUES(?, @report_id);`;
  
          connection.query({
              sql: sql_insert,
              values: [name, powerBiId, workspaceId, userID]
            }, function (error, results, fields) {
              if (error) throw error;
            });
        }
      } else {
        const sql_insert = `INSERT INTO ${REPORT_TABLE} (name, powerBiId, workspaceId) VALUES(?,?,?);`;
  
          connection.query({
              sql: sql_insert,
              values: [name, powerBiId, workspaceId]
            }, function (error, results, fields) {
              if (error) throw error;
            });
      }


      connection.end();

      
      context.res = {
          // status: 200, /* Defaults to 200 */
          body: "success"
      };
    } else {
      context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
      };
    }
}  catch(e){
    console.log("came here",e)
    context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
    };
} 

    
}