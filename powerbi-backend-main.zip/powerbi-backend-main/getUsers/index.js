const checkAuth = require('../auth/checkAuth');
const {REPORT_TABLE, USER_TABLE, USER_REPORT_TABLE} = require('../tableNames');
var mysql = require('mysql');
const util = require('util');

module.exports = async function (context, req) {
    try{
        var auth = req.headers.authorization;//get the Authorization header from the incoming request

        let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
        let result = await checkAuth(idToken); //await the result of our authentication check
        console.log("result", result)
        if(!result){
            throw Error("Invalid token.")
        }

        var connection = mysql.createConnection({
            host     : process.env.db_host,
            user     : process.env.db_user,
            password : process.env.db_password,
            database : process.env.database_name,
            multipleStatements: true
          });

        // node native promisify
        const query = util.promisify(connection.query).bind(connection);

        if (result.roles.includes('Admin.Privilege')) {
            const id = context.bindingData.id;
            const sql_get_all_reports = `SELECT * FROM ${USER_TABLE} WHERE archived=0 AND id = ${id.toString()};`;

            const sql_get_user_reports = `SELECT r.id AS id, r.name AS name, r.powerBiId AS powerBiID, r.workspaceId AS workspaceId FROM ${REPORT_TABLE} AS r JOIN ${USER_REPORT_TABLE} AS u ON u.reportId = r.id WHERE u.userId = ${id.toString()};`;

            const user_reports = await query(sql_get_user_reports);

            let responseMessage = [];
            responseMessage = await query(sql_get_all_reports);

            context.res = {
                // status: 200, /* Defaults to 200 */
                body: {
                    email : responseMessage[0].email,
                    id : responseMessage[0].id,
                    reports: user_reports
                }
            };
        } 
        connection.end()
        
    }  catch(e){
        console.log("came here",e)
        context.res = {
            // status: 200, /* Defaults to 200 */
            status: 403
            // body: responseMessage
        };
    } 

}