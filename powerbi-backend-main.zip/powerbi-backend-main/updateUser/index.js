const checkAuth = require('../auth/checkAuth');
var mysql = require('mysql');
const {USER_TABLE, USER_REPORT_TABLE} = require('../tableNames');
const util = require('util');

module.exports = async function (context, req) {
  try{
    var auth = req.headers.authorization;//get the Authorization header from the incoming request

    let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
    let result = await checkAuth(idToken); //await the result of our authentication check
    console.log("result", result)
    if(!result){
        throw Error("Invalid token.")
    }
    if (result.roles.includes('Admin.Privilege')) {
      var connection = mysql.createConnection({
        host     : process.env.db_host,
        user     : process.env.db_user,
        password : process.env.db_password,
        database : process.env.database_name,
        multipleStatements: true
      });
      const id = context.bindingData.id;

      // node native promisify
      const query = util.promisify(connection.query).bind(connection);

      const email = req.body.email;
      const reports = req.body.reports;

      const sql_update_users = `UPDATE ${USER_TABLE} SET email=? WHERE id=?;`;

      connection.query({
          sql: sql_update_users,
          values: [email,id]
        }, function (error, results, fields) {
          if (error) throw error;
        });
        const sql_delete_report = `DELETE FROM ${USER_REPORT_TABLE} WHERE userId = ?;`;
            connection.query({
              sql: sql_delete_report,
              values: [id]
            }, function (error, results, fields) {
              if (error) throw error;
            });
      
      let userId = id;


      for (const reportId of reports) {
        const sql_insert_reports = `INSERT IGNORE INTO ${USER_REPORT_TABLE} (userId, reportId) VALUES(?,?);`;

      connection.query({
          sql: sql_insert_reports,
          values: [userId, reportId]
        }, function (error, results, fields) {
          if (error) throw error;
        });
      }

      connection.end();
      
      context.res = {
          // status: 200, /* Defaults to 200 */
          body: "success"
      };
    } else {
      context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
      };
    }
}  catch(e){
    console.log("came here",e)
    context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
    };
} 

    
}