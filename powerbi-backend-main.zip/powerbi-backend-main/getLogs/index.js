const checkAuth = require('../auth/checkAuth');
const {VIEW_LOGS_TABLE} = require('../tableNames');
var queryString = require("query-string")
var mysql = require('mysql');
const util = require('util');

module.exports = async function (context, req) {
    try{
        var auth = req.headers.authorization;//get the Authorization header from the incoming request

        let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
        let result = await checkAuth(idToken); //await the result of our authentication check
        // console.log("result", result)
        if(!result){
            throw Error("Invalid token.")
        }

        var connection = mysql.createConnection({
            host     : process.env.db_host,
            user     : process.env.db_user,
            password : process.env.db_password,
            database : process.env.database_name,
            multipleStatements: true
          });

        const _queryString = req.url.split("?")[1]??"";

        const params = queryString.parse(_queryString, {arrayFormat: 'bracket'});

        const fromDate = req.query.fromDate;
        const toDate = req.query.toDate;
        const page = req.query.page;
        const reports = ((params.reports??[]).map(report => parseInt(report,10)));
        const users = ((params.users??[]).map(usr => parseInt(usr,10)));

        // node native promisify
        const query = util.promisify(connection.query).bind(connection);

        let logs = [];
        if (result.roles.includes('Admin.Privilege')) {
            let sql_get_logs = `SELECT * FROM ${VIEW_LOGS_TABLE}`;
            if (fromDate && toDate) {
                sql_get_logs = `SELECT * FROM ${VIEW_LOGS_TABLE} WHERE time BETWEEN '${new Date(fromDate).toISOString()}' AND '${new Date(toDate).toISOString()}' ORDER BY time DESC`;
            } else if (fromDate && !toDate) {
                sql_get_logs = `SELECT * FROM ${VIEW_LOGS_TABLE} WHERE time >= '${new Date(fromDate).toISOString()}' ORDER BY time DESC`;
            } else if (!fromDate && toDate) {
                sql_get_logs = `SELECT * FROM ${VIEW_LOGS_TABLE} WHERE time <= '${new Date(toDate).toISOString()}' ORDER BY time DESC`;
            }

            logs = await query(sql_get_logs);

            if (users.length) {
                logs = logs.filter(el => users.includes(el.userId));
            }

            if (reports.length) {
                logs = logs.filter(el => reports.includes(el.reportId));
            }

            const total = logs.length;

            const final = logs.slice((parseInt(page,10)-1)*25);
            context.res = {
                // status: 200, /* Defaults to 200 */
                body: { total : total, logs: final}
            };
        } 
        connection.end()
        
    }  catch(e){
        console.log("came here",e)
        context.res = {
            // status: 200, /* Defaults to 200 */
            status: 403
            // body: responseMessage
        };
    } 

}