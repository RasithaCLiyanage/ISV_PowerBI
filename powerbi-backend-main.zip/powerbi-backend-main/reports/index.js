const checkAuth = require('../auth/checkAuth');
const {REPORT_TABLE, USER_TABLE, USER_REPORT_TABLE} = require('../tableNames');
var mysql = require('mysql');
const util = require('util');

module.exports = async function (context, req) {
    try{
        var auth = req.headers.authorization;//get the Authorization header from the incoming request

        let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
        let result = await checkAuth(idToken); //await the result of our authentication check
        console.log("result", result)
        if(!result){
            throw Error("Invalid token.")
        }

        var connection = mysql.createConnection({
            host     : process.env.db_host,
            user     : process.env.db_user,
            password : process.env.db_password,
            database : process.env.database_name,
            multipleStatements: true
          });

        // node native promisify
        const query = util.promisify(connection.query).bind(connection);

        if (result.roles.includes('Admin.Privilege')) {
            const sql_get_all_reports = `SELECT * FROM ${REPORT_TABLE} WHERE archived=0;`;

            let responseMessage = [];
            responseMessage = await query(sql_get_all_reports);

            context.res = {
                // status: 200, /* Defaults to 200 */
                body: responseMessage
            };
        } else {
            let responseMessage = [];
            const email = result.preferred_username;
            const sql_get_user = `SELECT id FROM ${USER_TABLE} WHERE email = '${email}';`;

            const user_rows = await query(sql_get_user);

            if (user_rows.length) {
                const userId = user_rows[0].id;

                const sql_get_user_reports = `SELECT r.id AS id, r.powerBiId AS powerBiId, r.workspaceId AS workspaceId, r.name AS name FROM ${REPORT_TABLE} AS r JOIN ${USER_REPORT_TABLE} AS u ON r.id = u.reportId WHERE archived=false AND u.userId = ${userId.toString()};`;

                const data = await query(sql_get_user_reports);

                responseMessage = data;
            }

            connection.end();
            
            // responseMessage = [{id: 1, name: 'report one'}, {id:2, name: 'report two'}, {id:3, name: 'report three'}, {id:4, name: 'report four'}, {id:5, name: 'report five'}, {id:6, name: 'report six'}];

            context.res = {
                // status: 200, /* Defaults to 200 */
                body: responseMessage
            };
        }
        
    }  catch(e){
        console.log("came here",e)
        context.res = {
            // status: 200, /* Defaults to 200 */
            status: 403
            // body: responseMessage
        };
    } 

}