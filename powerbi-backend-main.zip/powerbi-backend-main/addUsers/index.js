const checkAuth = require('../auth/checkAuth');
var mysql = require('mysql');
const {USER_TABLE, USER_REPORT_TABLE} = require('../tableNames');
const util = require('util');

module.exports = async function (context, req) {
  try{
    var auth = req.headers.authorization;//get the Authorization header from the incoming request

    let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
    let result = await checkAuth(idToken); //await the result of our authentication check
    console.log("result", result)
    if(!result){
        throw Error("Invalid token.")
    }
    if (result.roles.includes('Admin.Privilege')) {
      var connection = mysql.createConnection({
        host     : process.env.db_host,
        user     : process.env.db_user,
        password : process.env.db_password,
        database : process.env.database_name,
        multipleStatements: true
      });

      // node native promisify
      const query = util.promisify(connection.query).bind(connection);

      const email = req.body.email;
      const reports = req.body.reports;

      const sql_insert_users = `INSERT INTO ${USER_TABLE} (email) VALUES(?);`;

      connection.query({
          sql: sql_insert_users,
          values: [email]
        }, function (error, results, fields) {
          if (error) throw error;
        });

      const sql_get_userId = `SELECT id FROM ${USER_TABLE} WHERE email = '${email}';`;
      
      let userId = null;

      // connection.query({
      //   sql: sql_get_userId,
      //   values: [email]
      // }, function (error, results, fields) {
      //   if (error) throw error;
      //   userId = results[0].id;
      // });

      const userIds = await query(sql_get_userId);

      if (userIds.length) {
        userId = userIds[0].id;
      }

      for (const reportId of reports) {
        const sql_insert_reports = `INSERT INTO ${USER_REPORT_TABLE} (userId, reportId) VALUES(?,?);`;

      connection.query({
          sql: sql_insert_reports,
          values: [userId, reportId]
        }, function (error, results, fields) {
          if (error) throw error;
        });
      }

      connection.end();
      
      context.res = {
          // status: 200, /* Defaults to 200 */
          body: "success"
      };
    } else {
      context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
      };
    }
}  catch(e){
    console.log("came here",e)
    context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
    };
} 

    
}