const checkAuth = require('../auth/checkAuth');
var mysql      = require('mysql');
const {REPORT_TABLE, USER_TABLE, USER_REPORT_TABLE, VIEW_LOGS_TABLE} = require('../tableNames');
let embedToken = require(__dirname + '/embedTokenGenerationService.js');
const util = require('util');

module.exports = async function (context, req) {
    // Get the details like Embed URL, Access token and Expiry
    try{
        var auth = req.headers.authorization;//get the Authorization header from the incoming request
    
        let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
        let result = await checkAuth(idToken); //await the result of our authentication check
        console.log("result", result)
        if(!result){
            throw Error("Invalid token.")
        }
        var connection = mysql.createConnection({
            host     : process.env.db_host,
            user     : process.env.db_user,
            password : process.env.db_password,
            database : process.env.database_name,
            multipleStatements: true
          });

          // node native promisify
        const query = util.promisify(connection.query).bind(connection);
        const id = context.bindingData.id;
        const sql_insert_logs = `INSERT INTO ${VIEW_LOGS_TABLE} (userId, reportId, email, report_name) VALUES(?, ?, ?, ?);`;
        const email = result.preferred_username;
        if (result.roles.includes('Admin.Privilege')) {
            // if(true){
            console.log("id",id)

            const sql_get_report = `SELECT * FROM ${REPORT_TABLE} WHERE id=${id.toString()}`;

            const report_rows = await query(sql_get_report);
            console.log(report_rows)

            if (report_rows.length) {
                const report = report_rows[0];

                let result = await embedToken.generateEmbedToken(report.powerBiId, report.workspaceId);
                console.log("reponse", {token : result, powerBiId: report.powerBiId})
                const sql_get_admin = `SELECT id FROM ${USER_TABLE} WHERE email = '${email}';`;

                const admin_rows = await query(sql_get_admin);
                if(admin_rows.length) {
                    
                    const adminId = admin_rows[0].id;
                    connection.query({
                        sql: sql_insert_logs,
                        values: [adminId, id, email, report.name]
                    }, function (error, results, fields) {
                        if (error) throw error;
                    });
                }
                
                context.res = {
                    // status: result.status, /* Defaults to 200 */
                    body: {token : result, powerBiId: report.powerBiId}
                };


            } else {
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    status: 404
                    // body: responseMessage
                };
            }
  
            
        } else {
            const sql_get_user = `SELECT id FROM ${USER_TABLE} WHERE email = '${email}';`;

            const user_rows = await query(sql_get_user);

            if (user_rows.length) {
                const userId = user_rows[0].id;

                const sql_get_user_reports = `SELECT r.id AS id, r.powerBiId AS powerBiId, r.workspaceId AS workspaceId, r.name AS name FROM ${REPORT_TABLE} AS r JOIN ${USER_REPORT_TABLE} AS u ON r.id = u.reportId WHERE archived=0 AND u.userId = ${userId.toString()} AND r.id = ${id.toString()};`;

                const data = await query(sql_get_user_reports);

                if (data.length) {
                    const report = data[0];

                    connection.query({
                        sql: sql_insert_logs,
                        values: [userId, id, email, report.name]
                    }, function (error, results, fields) {
                        if (error) throw error;
                    });

                    let _result = await embedToken.generateEmbedToken(report.powerBiId, report.workspaceId);

                    context.res = {
                    // status: result.status, /* Defaults to 200 */
                        body: {token : _result, powerBiId: report.powerBiId}
                    };
                } else {
                    context.res = {
                        // status: 200, /* Defaults to 200 */
                        status: 404
                        // body: responseMessage
                    };
                }

            } else {
                context.res = {
                    // status: 200, /* Defaults to 200 */
                    status: 404
                    // body: responseMessage
                };
            }
        }
    }  catch(e){
        console.log("came here",e)
        context.res = {
            // status: 200, /* Defaults to 200 */
            status: 403
            // body: responseMessage
        };
    } 
    
}