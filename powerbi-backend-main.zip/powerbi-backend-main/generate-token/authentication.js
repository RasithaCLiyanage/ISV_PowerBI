const getAuthenticationToken = async function () {
    // Use ADAL.js for authentication
    let adal = require('adal-node');

    let AuthenticationContext = adal.AuthenticationContext;

    // Create a config variable that store credentials from config.json
    let config = require(__dirname + '/../config/config.json');

    let authorityUrl = process.env.authorityUri;

    authorityUrl = authorityUrl.replace('common', process.env.tenantId);
    let context = new AuthenticationContext(authorityUrl);

    return new Promise((resolve, reject) => {
        context.acquireTokenWithClientCredentials(process.env.scope, process.env.clientId, process.env.clientSecret, function (err, tokenResponse) {
            // Function returns error object in tokenResponse
            // Invalid Username will return empty tokenResponse, thus err is used
            if (err) {
                reject(tokenResponse == null ? err : tokenResponse);
            }
            resolve(tokenResponse);
        });
    });
};

module.exports.getAuthenticationToken = getAuthenticationToken;
