const db = process.env.database_name;
// export const USER_TABLE = `${db}.users`;
// export const REPORT_TABLE = `${db}.reports`;
// export const USER_REPORT_TABLE = `${db}.user_reports`;

module.exports = {
    USER_TABLE: `${db}.users`,
    REPORT_TABLE: `${db}.reports`,
    USER_REPORT_TABLE: `${db}.user_reports`,
    VIEW_LOGS_TABLE: `${db}.report_access_log`
}
