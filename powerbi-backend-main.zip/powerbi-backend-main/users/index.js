const checkAuth = require('../auth/checkAuth');
const {USER_TABLE} = require('../tableNames');
var mysql = require('mysql');
const util = require('util');

module.exports = async function (context, req) {
    try{
        var auth = req.headers.authorization;//get the Authorization header from the incoming request

        let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
        let result = await checkAuth(idToken); //await the result of our authentication check
        console.log("result", result)
        if(!result){
            throw Error("Invalid token.")
        }
        
        if (result.roles.includes('Admin.Privilege')) {  // Todo: make it 'Admin.Privilege'
            let responseMessage = [];
            var connection = mysql.createConnection({
                host     : process.env.db_host,
                user     : process.env.db_user,
                password : process.env.db_password,
                database : process.env.database_name,
                multipleStatements: true
              });

              // node native promisify
            const query = util.promisify(connection.query).bind(connection);

            const sql_get_all_users = `SELECT id, email FROM ${USER_TABLE} WHERE archived = 0;`;

            const rows = await query(sql_get_all_users);

            context.res = {
                status: 200, /* Defaults to 200 */
                body: rows
            };
            
            
            connection.end();
            
        } else {
            context.res = {
                // status: 200, /* Defaults to 200 */
                status: 403
                // body: responseMessage
            };
        }
    }  catch(e){
        console.log("came here",e)
        context.res = {
            // status: 200, /* Defaults to 200 */
            status: 403
            // body: responseMessage
        };
    } 

}