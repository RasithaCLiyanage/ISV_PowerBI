const checkAuth = require('../auth/checkAuth');
var mysql      = require('mysql');
const {REPORT_TABLE} = require('../tableNames');

module.exports = async function (context, req) {

    try{
      var auth = req.headers.authorization;//get the Authorization header from the incoming request
  
      let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
      let result = await checkAuth(idToken); //await the result of our authentication check
      console.log("result", result)
      if(!result){
          throw Error("Invalid token.")
      }
      if (result.roles.includes('Admin.Privilege')) {
          var connection = mysql.createConnection({
            host     : process.env.db_host,
            user     : process.env.db_user,
            password : process.env.db_password,
            database : process.env.database_name,
            multipleStatements: true
          });
        const id = context.bindingData.id;

        const sql_delete = `UPDATE ${REPORT_TABLE} SET archived=1 WHERE id=?;`;

        connection.query({
            sql: sql_delete,
            values: [id]
          }, function (error, results, fields) {
            if (error) throw error;
          });

        connection.end();
        
        context.res = {
            // status: 200, /* Defaults to 200 */
            body: "success"
        };
      } else {
        context.res = {
          // status: 200, /* Defaults to 200 */
          status: 403
          // body: responseMessage
        };
      }
  }  catch(e){
      console.log("came here",e)
      context.res = {
          // status: 200, /* Defaults to 200 */
          status: 403
          // body: responseMessage
      };
  } 
}