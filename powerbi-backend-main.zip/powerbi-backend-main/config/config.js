const getConfig = () => ({
    authenticationMode: 'ServicePrincipal',
    authorityUri: 'https://login.microsoftonline.com/common/v2.0',
    scope: 'https://analysis.windows.net/powerbi/api',
    clientId: process.env.POWERBI_CLIENT_ID,
    workspaceId: process.env.WORKSPACE_ID,
    reportId: '079a3456-4d22-457d-af1b-c788ab67266f',
    clientSecret: process.env.CLIENT_SECRET,
    tenantId: process.env.TENENT_ID,
});

export default getConfig;
