const checkAuth = require('../auth/checkAuth');
var mysql = require('mysql');
const {REPORT_TABLE, USER_REPORT_TABLE} = require('../tableNames');

module.exports = async function (context, req) {
  try{
    var auth = req.headers.authorization;//get the Authorization header from the incoming request

    let idToken = auth.substring(7);//removes "Bearer " from the Authorization header
    let result = await checkAuth(idToken); //await the result of our authentication check
    console.log("result", result)
    if(!result){
        throw Error("Invalid token.")
    }
    if (result.roles.includes('Admin.Privilege')) {
        var connection = mysql.createConnection({
          host     : process.env.db_host,
          user     : process.env.db_user,
          password : process.env.db_password,
          database : process.env.database_name,
          multipleStatements: true
        });

      const id = context.bindingData.id;

      const users = req.body.users;
      const name = req.body.name;
      const powerBiId = req.body.powerBiId;
      const wokspaceId = req.body.workspaceId;

      const sql_update = `UPDATE ${REPORT_TABLE} SET name=?, powerBiId=?, workspaceId=? WHERE id=?;`;

        connection.query({
            sql: sql_update,
            values: [name, powerBiId, wokspaceId, id]
          }, function (error, results, fields) {
            if (error) throw error;
          });
            const sql_delete_users = `DELETE FROM ${USER_REPORT_TABLE} WHERE reportId = ?;`;
            connection.query({
              sql: sql_delete_users,
              values: [id]
            }, function (error, results, fields) {
              if (error) throw error;
            });

      for (const userID of users) {
        const sql_update_users = `INSERT IGNORE INTO ${USER_REPORT_TABLE} (userId, reportId) VALUES (?,?);`;
        connection.query({
          sql: sql_update_users,
          values: [userID, id]
        }, function (error, results, fields) {
          if (error) throw error;
        });
      }

      connection.end();

      
      context.res = {
          // status: 200, /* Defaults to 200 */
          body: "success"
      };
    } else {
      context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
      };
    }
}  catch(e){
    console.log("came here",e)
    context.res = {
        // status: 200, /* Defaults to 200 */
        status: 403
        // body: responseMessage
    };
} 

    
}