import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  user: null,
  isAdmin: false
};

export const authUserSlice = createSlice({
  name: 'authUser',
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.user = action.payload;
      state.isAdmin = action.payload.idTokenClaims?.roles?.includes('Admin.Privilege');
    }
  }
});

export const { setUser } = authUserSlice.actions;

export default authUserSlice.reducer;
