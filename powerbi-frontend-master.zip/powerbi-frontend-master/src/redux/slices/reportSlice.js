import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
// eslint-disable-next-line import/no-named-as-default
import apiService from '../../http/apiService';

const initialState = {
  loading: true,
  report: {}
};

export const getReport = createAsyncThunk('report', async (reportId) => apiService.reports.fetchOne(reportId));

export const reportSlice = createSlice({
  name: 'counter',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getReport.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getReport.fulfilled, (state, { payload }) => {
      state.loading = false;
      state.report = payload;
    });
  }
});

export default reportSlice.reducer;
