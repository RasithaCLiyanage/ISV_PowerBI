import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import apiService from '../../http/apiService';

const initialState = {
  loading: true,
  users: [],
  user: {
    progress: false,
    data: null
  },
  transaction: {
    progress: false,
    errors: null
  }
};

export const getUsers = createAsyncThunk('users', async () => apiService.users.all());
export const addUser = createAsyncThunk('users/add', async (data) => apiService.users.add(data));
export const updateUser = createAsyncThunk('users/update', async ({ id, user }) => apiService.users.update(id, user));
export const getUser = createAsyncThunk('users/get', async (id) => apiService.users.get(id));

export const usersSlice = createSlice({
  name: 'users',
  initialState,
  reducers: {
    closeFormErrors: (state) => {
      state.transaction.errors = null;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(getUsers.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getUsers.fulfilled, (state, { payload }) => {
      state.loading = false;
      state.users = payload;
    });
    builder.addCase(addUser.pending, (state) => {
      state.transaction.progress = true;
    });
    builder.addCase(addUser.fulfilled, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = false;
    });
    builder.addCase(addUser.rejected, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = true;
    });
    builder.addCase(updateUser.pending, (state) => {
      state.transaction.progress = true;
    });
    builder.addCase(updateUser.fulfilled, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = false;
    });
    builder.addCase(updateUser.rejected, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = true;
    });
    builder.addCase(getUser.pending, (state) => {
      state.user.progress = true;
      state.user.data = null;
    });
    builder.addCase(getUser.fulfilled, (state, { payload }) => {
      state.user.progress = false;
      state.user.data = payload;
    });
    builder.addCase(getUser.rejected, (state) => {
      state.user.progress = false;
      state.transaction.errors = true;
    });
  }
});

export const { closeFormErrors } = usersSlice.actions;

export default usersSlice.reducer;
