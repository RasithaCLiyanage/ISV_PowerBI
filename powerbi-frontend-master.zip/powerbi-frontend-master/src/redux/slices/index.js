import AuthUserSlice from './authUserSlice';
import ReportsReducer from './reportsSlice';
import ReportReducer from './reportSlice';
import UsersSlice from './usersSlice';
import AccessLogSlice from './accessLogSlice';

const slices = {
  reports: ReportsReducer,
  showReport: ReportReducer,
  auth: AuthUserSlice,
  users: UsersSlice,
  accessLogs: AccessLogSlice
};

export default slices;
