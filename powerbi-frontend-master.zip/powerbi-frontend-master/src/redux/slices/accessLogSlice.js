import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
// eslint-disable-next-line import/no-named-as-default
import apiService from '../../http/apiService';

const initialState = {
  loading: true,
  pagination: {
    total: 0
  },
  data: []
};

export const getAccessLogs = createAsyncThunk('accessLogs/all', async (filters) => apiService.logs.all(filters));

export const accessLog = createSlice({
  name: 'accessLog',
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getAccessLogs.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getAccessLogs.fulfilled, (state, { payload }) => {
      state.loading = false;
      state.data = payload;
      state.pagination.total = payload.total;
      state.data = payload.logs;
    });
  }
});

export default accessLog.reducer;
