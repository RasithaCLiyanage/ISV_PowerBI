import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import apiService from '../../http/apiService';

const initialState = {
  loading: false,
  reports: [],
  report: {
    progress: false,
    data: null
  },
  transaction: {
    progress: false,
    errors: null
  }
};

export const fetchReports = createAsyncThunk('reports/all', async () => apiService.reports.all());
export const addReport = createAsyncThunk('reports/add', async (data) => apiService.reports.add(data));
export const updateReport = createAsyncThunk('reports/update', async ({ id, report }) => apiService.reports.update(id, report));
export const getReport = createAsyncThunk('reports/get', async (id) => apiService.reports.get(id));

export const reportsSlice = createSlice({
  name: 'counter',
  initialState,
  reducers: {
    closeFormErrors: (state) => {
      state.transaction.errors = null;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchReports.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchReports.fulfilled, (state, { payload }) => {
      state.loading = false;
      state.reports = payload;
    });
    builder.addCase(addReport.pending, (state) => {
      state.transaction.progress = true;
    });
    builder.addCase(addReport.fulfilled, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = false;
    });
    builder.addCase(addReport.rejected, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = true;
    });
    builder.addCase(updateReport.pending, (state) => {
      state.transaction.progress = true;
    });
    builder.addCase(updateReport.fulfilled, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = false;
    });
    builder.addCase(updateReport.rejected, (state) => {
      state.transaction.progress = false;
      state.transaction.errors = true;
    });
    builder.addCase(getReport.pending, (state) => {
      state.report.progress = true;
      state.report.data = null;
    });
    builder.addCase(getReport.fulfilled, (state, { payload }) => {
      state.report.progress = false;
      state.report.data = payload;
    });
  }
});

export const { closeFormErrors } = reportsSlice.actions;

export default reportsSlice.reducer;
