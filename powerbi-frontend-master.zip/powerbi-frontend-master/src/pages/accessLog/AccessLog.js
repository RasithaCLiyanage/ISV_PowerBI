import {
  Autocomplete,
  Checkbox,
  Container,
  FormControl,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Pagination
} from '@mui/material';
import { forwardRef, useEffect, useMemo, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import InsertInvitationIcon from '@mui/icons-material/InsertInvitation';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import DatePicker from 'react-datepicker';
import { getAccessLogs } from '../../redux/slices/accessLogSlice';
import { getUsers } from '../../redux/slices/usersSlice';
import 'react-datepicker/dist/react-datepicker.css';
import { fetchReports } from '../../redux/slices/reportsSlice';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const DateInputField = forwardRef(({ value, onClick, placeholder }, ref) => (
  <FormControl variant="outlined" fullWidth>
    <InputLabel htmlFor="outlined-adornment-password">{placeholder}</InputLabel>
    <OutlinedInput
      id="standard-adornment-password"
      type="text"
      value={value}
      label={placeholder}
      inputProps={{
        readOnly: true
      }}
      endAdornment={
        <InputAdornment position="end">
          <IconButton aria-label="toggle password visibility" onClick={onClick} ref={ref}>
            <InsertInvitationIcon />
          </IconButton>
        </InputAdornment>
      }
    />
  </FormControl>
));

// eslint-disable-next-line arrow-body-style
const AccessLog = () => {
  const dispatch = useDispatch();
  const logs = useSelector((state) => state.accessLogs);
  const users = useSelector((state) => state.users);
  const reports = useSelector((state) => state.reports);
  const [page, setPage] = useState(1);

  const { control, getValues } = useForm({
    defaultValues: {
      fromDate: null,
      toDate: null,
      reports: [],
      users: []
    },
    mode: 'onChange'
  });

  const applyFilters = () => {
    const values = getValues();
    const filters = {
      users: values.users.map((user) => user.id),
      reports: values.reports.map((report) => report.id),
      page
    };

    if (values.fromDate) {
      filters.fromDate = values.fromDate.toISOString();
    }

    if (values.toDate) {
      filters.toDate = values.toDate.toISOString();
    }

    dispatch(getAccessLogs(filters));
  };

  useEffect(() => {
    applyFilters();
    dispatch(getUsers());
    dispatch(fetchReports());
  }, []);

  const pageCount = useMemo(() => Math.ceil(logs.pagination.total / 25), [logs.pagination.total]);

  return (
    <Container sx={{ marginTop: 4 }}>
      <form>
        <Grid container rowSpacing={2} columnSpacing={{ xs: 1, sm: 2, md: 3 }} sx={{ marginBottom: 4 }}>
          <Grid item xs={12}>
            <Controller
              name="reports"
              control={control}
              render={({ field }) => (
                <FormControl fullWidth>
                  <Autocomplete
                    {...field}
                    multiple
                    id="reports"
                    options={reports.reports}
                    disableCloseOnSelect
                    getOptionLabel={(option) => option.name}
                    renderOption={(props, option, { selected }) => (
                      <li {...props}>
                        <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                        {option.name}
                      </li>
                    )}
                    renderInput={(params) => <TextField {...params} label="Reports" />}
                    onChange={(_, selected, reason) => {
                      field.onChange(selected);
                      if (reason === 'removeOption') {
                        applyFilters();
                      }
                    }}
                    onClose={() => applyFilters()}
                    control={control}
                  />
                </FormControl>
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <Controller
              name="users"
              control={control}
              render={({ field }) => (
                <FormControl fullWidth>
                  <Autocomplete
                    {...field}
                    multiple
                    id="users"
                    options={users.users}
                    disableCloseOnSelect
                    getOptionLabel={(option) => option.email}
                    isOptionEqualToValue={(option, value) => option.id === value.id}
                    renderOption={(props, option, { selected }) => (
                      <li {...props}>
                        <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                        {option.email}
                      </li>
                    )}
                    renderInput={(params) => <TextField {...params} label="Users" />}
                    onChange={(_, selected, reason) => {
                      field.onChange(selected);
                      if (reason === 'removeOption') {
                        applyFilters();
                      }
                    }}
                    onClose={() => applyFilters()}
                    control={control}
                  />
                </FormControl>
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3} lg={4}>
            <Controller
              name="fromDate"
              control={control}
              render={({ field }) => (
                <FormControl fullWidth>
                  <DatePicker
                    selected={field.value}
                    onChange={(date) => field.onChange(date)}
                    timeInputLabel="Time:"
                    dateFormat="MM/dd/yyyy h:mm aa"
                    showTimeInput
                    onCalendarClose={() => applyFilters()}
                    customInput={<DateInputField />}
                    placeholderText="From date"
                  />
                </FormControl>
              )}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3} lg={4}>
            <Controller
              name="toDate"
              control={control}
              render={({ field }) => (
                <FormControl fullWidth>
                  <DatePicker
                    selected={field.value}
                    onChange={(date) => field.onChange(date)}
                    timeInputLabel="Time:"
                    dateFormat="MM/dd/yyyy h:mm aa"
                    showTimeInput
                    onCalendarClose={() => applyFilters()}
                    customInput={<DateInputField />}
                    placeholderText="To date"
                  />
                </FormControl>
              )}
            />
          </Grid>
        </Grid>
      </form>

      <>
        <TableContainer component={Paper} sx={{ marginBottom: 3 }}>
          <Table size="small">
            <caption>Access log</caption>
            <TableHead>
              <TableRow>
                <TableCell>User</TableCell>
                <TableCell>Report</TableCell>
                <TableCell>Time</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {logs.data.map((log) => (
                <TableRow key={log.id}>
                  <TableCell component="th" scope="row">
                    {log.email}
                  </TableCell>
                  <TableCell component="th" scope="row">
                    {log.report_name}
                  </TableCell>
                  <TableCell component="th" scope="row">
                    {log.time}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        {pageCount > 0 && (
          <Pagination
            count={pageCount}
            page={page}
            color="primary"
            showFirstButton
            showLastButton
            disabled={logs.loading}
            sx={{ justifyContent: 'end', display: 'flex' }}
            onChange={(_, value) => {
              setPage(value);
              applyFilters();
            }}
          />
        )}
      </>
    </Container>
  );
};

export default AccessLog;
