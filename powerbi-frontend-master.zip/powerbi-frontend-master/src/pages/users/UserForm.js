import { memo, useEffect } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { Alert, Button, CardContent, CardHeader, FormControl, Grid, Snackbar, Stack, TextField } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { Link, useParams } from 'react-router-dom';
import Checkbox from '@mui/material/Checkbox';
import Autocomplete from '@mui/material/Autocomplete';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import { fetchReports } from '../../redux/slices/reportsSlice';
import { addUser, getUser, closeFormErrors, updateUser } from '../../redux/slices/usersSlice';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const UserForm = () => {
  const schema = yup
    .object({
      email: yup.string().email().required(),
      reports: yup.array()
    })
    .required();

  const {
    control,
    handleSubmit,
    formState: { errors, isDirty, isValid },
    setValue,
    watch,
    getValues
  } = useForm({
    defaultValues: {
      email: '',
      reports: []
    },
    resolver: yupResolver(schema),
    mode: 'onChange'
  });
  watch();
  const dispatch = useDispatch();
  const users = useSelector((state) => state.users);
  const reports = useSelector((state) => state.reports);
  const { id } = useParams();

  useEffect(() => {
    dispatch(fetchReports());
  }, [dispatch]);

  useEffect(() => {
    dispatch(closeFormErrors());
  }, []);

  useEffect(() => {
    if (id) {
      dispatch(getUser(id));
    }
  }, [id]);

  useEffect(() => {
    const isEdit = users.user.data !== null && id && !users.user.progress;
    const emailVal = isEdit ? users.user.data.email : '';
    const reportsVal = isEdit ? users.user.data?.reports ?? [] : [];
    const options = isEdit ? { shouldValidate: true, shouldDirty: true } : {};

    setValue('email', emailVal, options);
    setValue('reports', reportsVal, options);
  }, [users.user]);

  const onSubmit = (data) => {
    const user = { ...data };
    user.reports = user.reports.map((report) => report.id);
    dispatch(id ? updateUser({ id, user }) : addUser(user));
  };

  const closeErrors = () => {
    dispatch(closeFormErrors());
  };

  return (
    <>
      <Grid container justifyContent="center" spacing={1}>
        <Grid item md={8}>
          <CardHeader title={id ? 'EDIT A USER' : 'ADD A USER'} />
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)}>
              <Grid item container spacing={2} justify="center">
                <Grid item xs={12}>
                  <Controller
                    name="email"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        fullWidth
                        label="User email"
                        {...field}
                        error={undefined !== errors?.email}
                        helperText={errors.email?.message}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Controller
                    name="reports"
                    control={control}
                    render={({ field }) => (
                      <FormControl fullWidth>
                        <Autocomplete
                          {...field}
                          value={getValues('reports')}
                          multiple
                          id="reports"
                          options={reports.reports}
                          disableCloseOnSelect
                          getOptionLabel={(option) => option.name}
                          renderOption={(props, option, { selected }) => (
                            <li {...props}>
                              <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                              {option.name}
                            </li>
                          )}
                          renderInput={(params) => <TextField {...params} label="Reports" />}
                          onChange={(_, selected) => {
                            field.onChange(selected);
                          }}
                          control={control}
                        />
                      </FormControl>
                    )}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Grid sx={{ display: 'flex', justifyContent: 'end' }}>
                    <Button variant="outlined" type="button" sx={{ mr: 2 }} component={Link} to="/users">
                      Cancel
                    </Button>
                    <Button variant="contained" type="submit" disabled={!isDirty || !isValid || users.transaction.progress}>
                      Submit
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </CardContent>
        </Grid>
      </Grid>
      <Stack spacing={2} sx={{ width: '100%' }}>
        <Snackbar
          open={users.transaction.errors !== null}
          autoHideDuration={5000}
          onClose={closeErrors}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert
            variant="filled"
            onClose={closeErrors}
            severity={users.transaction.errors === false ? 'success' : 'error'}
            sx={{ width: '100%' }}
          >
            {users.transaction.errors === false ? 'Successfully saved' : 'Error while saving.'}
          </Alert>
        </Snackbar>
      </Stack>
    </>
  );
};

export default memo(UserForm);
