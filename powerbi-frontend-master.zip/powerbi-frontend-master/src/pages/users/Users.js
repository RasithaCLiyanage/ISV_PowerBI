import { Box, Button, Container, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { getUsers } from '../../redux/slices/usersSlice';

const Users = () => {
  const users = useSelector((state) => state.users);
  const user = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getUsers());
  }, [dispatch]);

  return (
    <Container>
      {user.isAdmin && (
        <Box mb={2} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Button variant="contained" component={Link} to="/user/new">
            Add a user
          </Button>
        </Box>
      )}

      <TableContainer component={Paper}>
        <Table size="small">
          <caption>Users</caption>
          <TableHead>
            <TableRow>
              <TableCell>Email</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.users.map((u) => (
              <TableRow key={u.id}>
                <TableCell component="th" scope="row">
                  {u.email}
                </TableCell>
                <TableCell align="right">
                  {user.isAdmin && (
                    <Button variant="text" color="warning" sx={{ mr: 0.5 }} component={Link} to={`/user/${u.id}/edit`}>
                      Edit
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
};

export default Users;
