import Container from '@mui/material/Container';
import { forwardRef, memo, useState } from 'react';
import { useMsalAuthentication } from '@azure/msal-react';
import { Snackbar } from '@mui/material';
import { useTranslation } from 'react-i18next';
import MuiAlert from '@mui/material/Alert';
import { InteractionType } from '@azure/msal-browser';
import { loginRequest } from '../config/auth';

const Alert = forwardRef((props, ref) => <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />);

const Login = () => {
  useMsalAuthentication(InteractionType.Redirect, loginRequest);

  const { t: tErrors } = useTranslation('errors');
  const [enabledLoginError, setEnableLoginError] = useState(false);

  return (
    <Container
      component="main"
      maxWidth="xs"
      sx={{
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <Snackbar
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        open={enabledLoginError}
        onClose={() => setEnableLoginError(!enabledLoginError)}
      >
        <Alert onClose={() => setEnableLoginError(!enabledLoginError)} severity="error" sx={{ width: '100%' }}>
          {tErrors('login')}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default memo(Login);
