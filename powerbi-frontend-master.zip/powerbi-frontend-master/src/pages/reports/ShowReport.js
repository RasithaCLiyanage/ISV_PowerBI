import { Box, Container, Fab, LinearProgress, Tooltip } from '@mui/material';
import { PowerBIEmbed } from 'powerbi-client-react';
import { useParams } from 'react-router-dom';
import { models } from 'powerbi-client';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import FullscreenExitIcon from '@mui/icons-material/FullscreenExit';
import { getReport } from '../../redux/slices/reportSlice';

const fabStyle = {
  zIndex: 9999,
  position: 'absolute',
  bottom: 16,
  right: 16
};

function toggleFullScreenFn(elem) {
  if (
    (document.fullScreenElement !== undefined && document.fullScreenElement === null) ||
    (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) ||
    (document.mozFullScreen !== undefined && !document.mozFullScreen) ||
    (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)
  ) {
    if (elem.requestFullScreen) {
      elem.requestFullScreen();
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullScreen) {
      elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
    } else if (elem.msRequestFullscreen) {
      elem.msRequestFullscreen();
    }
  } else if (document.cancelFullScreen) {
    document.cancelFullScreen();
  } else if (document.mozCancelFullScreen) {
    document.mozCancelFullScreen();
  } else if (document.webkitCancelFullScreen) {
    document.webkitCancelFullScreen();
  } else if (document.msExitFullscreen) {
    document.msExitFullscreen();
  }
}

const ShowReport = () => {
  const [fullScreen, setFullScreen] = useState(false);
  const params = useParams();
  const dispatch = useDispatch();
  const report = useSelector((state) => state.showReport);

  useEffect(() => {
    dispatch(getReport(params.id));
  }, [params.id]);

  const toggleFullScreen = () => {
    toggleFullScreenFn(document.body);
    setFullScreen(!fullScreen);
  };

  return (
    <>
      <Container>
        <Box>
          {report.loading ? (
            <Box>
              <LinearProgress />
            </Box>
          ) : (
            <Box className="full-screen-report">
              <PowerBIEmbed
                embedConfig={{
                  type: 'report', // Supported types: report, dashboard, tile, visual and qna
                  id: report.report.powerBiId,
                  embedUrl: report.report.token.embedUrl,
                  accessToken: report.report.token.accessToken,
                  tokenType: models.TokenType.Embed,
                  settings: {
                    panes: {
                      filters: {
                        expanded: false,
                        visible: false
                      }
                    }
                    //   background: models.BackgroundType.Transparent
                  }
                }}
                cssClassName="report-embeded"
              />
            </Box>
          )}
        </Box>
      </Container>
      <Fab sx={fabStyle} size="medium" color="primary" aria-label="add" onClick={toggleFullScreen}>
        <Tooltip title={fullScreen ? 'Exit fullscreen' : 'Fullscreen'}>{fullScreen ? <FullscreenExitIcon /> : <FullscreenIcon />}</Tooltip>
      </Fab>
    </>
  );
};

export default ShowReport;
