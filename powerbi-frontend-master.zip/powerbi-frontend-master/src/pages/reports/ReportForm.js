import { memo, useEffect } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { Alert, Button, CardContent, CardHeader, FormControl, Grid, Snackbar, Stack, TextField } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { Link, useParams } from 'react-router-dom';
import Checkbox from '@mui/material/Checkbox';
import Autocomplete from '@mui/material/Autocomplete';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import { addReport, getReport, closeFormErrors, updateReport } from '../../redux/slices/reportsSlice';
import { getUsers } from '../../redux/slices/usersSlice';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const ReportForm = () => {
  const schema = yup
    .object({
      name: yup.string().required(),
      powerBiId: yup.string().required(),
      workspaceId: yup.string().required(),
      users: yup.array()
    })
    .required();

  const {
    control,
    handleSubmit,
    formState: { errors, isDirty, isValid },
    setValue,
    watch,
    getValues
  } = useForm({
    defaultValues: {
      name: '',
      powerBiId: '',
      workspaceId: '',
      users: []
    },
    resolver: yupResolver(schema),
    mode: 'onChange'
  });
  watch();
  const dispatch = useDispatch();
  const users = useSelector((state) => state.users);
  const reports = useSelector((state) => state.reports);
  const { id } = useParams();

  useEffect(() => {
    dispatch(getUsers());
  }, [dispatch]);

  useEffect(() => {
    dispatch(closeFormErrors());
  }, []);

  useEffect(() => {
    if (id) {
      dispatch(getReport(id));
    }
  }, [id]);

  useEffect(() => {
    const isEdit = reports.report.data !== null && id;
    const nameVal = isEdit ? reports.report.data.name : '';
    const powerBiIdVal = isEdit ? reports.report.data.powerBiId : '';
    const workspaceIdVal = isEdit ? reports.report.data.workspaceId : '';
    const usersVal = isEdit ? reports.report.data?.users ?? [] : [];
    const options = isEdit ? { shouldValidate: true, shouldDirty: true } : {};

    setValue('name', nameVal, options);
    setValue('powerBiId', powerBiIdVal, options);
    setValue('workspaceId', workspaceIdVal, options);
    setValue('users', usersVal, options);
  }, [reports.report.data]);

  const onSubmit = (data) => {
    const report = { ...data };
    report.users = report.users.map((user) => user.id);
    dispatch(id ? updateReport({ id, report }) : addReport(report));
  };

  const closeErrors = () => {
    dispatch(closeFormErrors());
  };

  return (
    <>
      <Grid container justifyContent="center" spacing={1}>
        <Grid item md={8}>
          <CardHeader title={id ? 'EDIT A REPORT' : 'ADD A REPORT'} />
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)}>
              <Grid item container spacing={2} justify="center">
                <Grid item xs={12}>
                  <Controller
                    name="name"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        fullWidth
                        label="Report name"
                        {...field}
                        error={undefined !== errors?.name}
                        helperText={errors.name?.message}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Controller
                    name="powerBiId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        fullWidth
                        label="PowerBi id"
                        {...field}
                        error={undefined !== errors?.powerBiId}
                        helperText={errors.powerBiId?.message}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Controller
                    name="workspaceId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        fullWidth
                        label="Workspace id"
                        {...field}
                        error={undefined !== errors?.workspaceId}
                        helperText={errors.workspaceId?.message}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Controller
                    name="users"
                    control={control}
                    render={({ field }) => (
                      <FormControl fullWidth>
                        <Autocomplete
                          {...field}
                          value={getValues('users')}
                          multiple
                          id="users"
                          options={users.users}
                          disableCloseOnSelect
                          getOptionLabel={(option) => option.email}
                          isOptionEqualToValue={(option, value) => option.id === value.id}
                          renderOption={(props, option, { selected }) => (
                            <li {...props}>
                              <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                              {option.email}
                            </li>
                          )}
                          renderInput={(params) => <TextField {...params} label="Users" />}
                          onChange={(_, selected) => {
                            field.onChange(selected);
                          }}
                          control={control}
                        />
                      </FormControl>
                    )}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Grid sx={{ display: 'flex', justifyContent: 'end' }}>
                    <Button variant="outlined" type="button" sx={{ mr: 2 }} component={Link} to="/reports">
                      Cancel
                    </Button>
                    <Button variant="contained" type="submit" disabled={!isDirty || !isValid || reports.transaction.progress}>
                      Submit
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            </form>
          </CardContent>
        </Grid>
      </Grid>
      <Stack spacing={2} sx={{ width: '100%' }}>
        <Snackbar
          open={reports.transaction.errors !== null}
          autoHideDuration={5000}
          onClose={closeErrors}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert
            variant="filled"
            onClose={closeErrors}
            severity={reports.transaction.errors === false ? 'success' : 'error'}
            sx={{ width: '100%' }}
          >
            {reports.transaction.errors === false ? 'Successfully saved' : 'Error while saving.'}
          </Alert>
        </Snackbar>
      </Stack>
    </>
  );
};

export default memo(ReportForm);
