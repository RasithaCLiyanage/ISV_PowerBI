import { Box, Button, Container, Paper, Skeleton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { memo, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import { fetchReports } from '../../redux/slices/reportsSlice';

const StyledContainer = styled(Container)(({ theme }) => ({
  paddingBottom: theme.spacing(4),
  margin: 'auto',
  [theme.breakpoints.down('md')]: {
    width: '100%'
  },
  [theme.breakpoints.up('md')]: {
    width: '60%'
  }
}));

const Reports = () => {
  const dispatch = useDispatch();
  const reports = useSelector((state) => state.reports);
  const user = useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(fetchReports());
  }, []);

  const renderTableBody = () =>
    reports.reports.map((report) => (
      <TableRow key={report.id} hover>
        <TableCell component="th" scope="row">
          {report.name}
        </TableCell>
        <TableCell align="right">
          {user.isAdmin && (
            <Button variant="text" color="warning" sx={{ mr: 0.5 }} component={Link} to={`/report/${report.id}/edit`}>
              Edit
            </Button>
          )}
          <Button variant="contained" component={Link} to={`/report/${report.id}`} target="_blank">
            View
          </Button>
        </TableCell>
      </TableRow>
    ));

  const renderTableLoading = () =>
    [1, 2, 3].map((temp) => (
      <TableRow key={temp}>
        <TableCell component="th" scope="row">
          <Skeleton sx={{ bgcolor: 'grey.500', borderRadius: 0.5, height: 32 }} />
        </TableCell>
        <TableCell align="right">
          <Skeleton sx={{ bgcolor: 'grey.500', borderRadius: 0.5, height: 32 }} />
        </TableCell>
      </TableRow>
    ));

  return (
    <StyledContainer pb={4}>
      {user.isAdmin && (
        <Box mb={2} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Button variant="contained" component={Link} to="/report/new">
            Add a report
          </Button>
        </Box>
      )}

      <TableContainer
        component={Paper}
        style={{ backgroundColor: 'rgb(0 0 0 / 60%)' }}
        classes={{ root: 'reports-container' }}
        sx={{ padding: 4, mb: 4 }}
      >
        <Table size="small" className="reports-table">
          <caption>Reports</caption>
          <TableHead>
            <TableRow>
              <TableCell>Report name</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>{!reports.loading ? renderTableBody() : renderTableLoading()}</TableBody>
        </Table>
      </TableContainer>
    </StyledContainer>
  );
};

export default memo(Reports);
