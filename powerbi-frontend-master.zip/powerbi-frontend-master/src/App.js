import { MsalProvider } from '@azure/msal-react';
import './App.css';
import AppRoutes from './components/AppRoutes';

function App({ pca }) {
  return (
    <MsalProvider instance={pca}>
      <AppRoutes />
    </MsalProvider>
  );
}

export default App;
