import { memo } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AccessLog from '../pages/accessLog/AccessLog';
import ReportForm from '../pages/reports/ReportForm';
import Reports from '../pages/reports/Reports';
import ShowReport from '../pages/reports/ShowReport';
import UserForm from '../pages/users/UserForm';
import Users from '../pages/users/Users';
import Layout from './Layout';

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Layout />}>
      <Route exact path="/" element={<Navigate to="/reports" />} />
      <Route exact path="/reports" element={<Reports />} />
      <Route exact path="/report/:id" element={<ShowReport />} />
      <Route exact path="/report/:id/edit" element={<ReportForm />} />
      <Route exact path="/report/new" element={<ReportForm />} />
      <Route exact path="/users" element={<Users />} />
      <Route exact path="/user/:id/edit" element={<UserForm />} />
      <Route exact path="/user/new" element={<UserForm />} />
      <Route exact path="/access-log" element={<AccessLog />} />
    </Route>
  </Routes>
);
export default memo(AppRoutes);
