import { Container, List, ListItem, ListItemIcon, ListItemText, Skeleton, Tooltip, Typography } from '@mui/material';
import AssessmentIcon from '@mui/icons-material/Assessment';
import { memo } from 'react';
import { useSelector } from 'react-redux';

const RightDrawerMenu = () => {
  const reports = useSelector((state) => state.reports);

  return (
    <>
      {reports.loading ? (
        <Container>
          {Array(5)
            .fill()
            .map(() => (
              <Typography component="div" variant="h3">
                <Skeleton />
              </Typography>
            ))}
        </Container>
      ) : (
        <List>
          {reports.reports.map((report) => (
            <Tooltip title={report.name} placement="right">
              <ListItem button key={report.id}>
                <ListItemIcon>
                  <AssessmentIcon />
                </ListItemIcon>
                <ListItemText primary={report.name} />
              </ListItem>
            </Tooltip>
          ))}
        </List>
      )}
    </>
  );
};

export default memo(RightDrawerMenu);
