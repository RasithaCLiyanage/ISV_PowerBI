import { useMsal } from '@azure/msal-react';
import { Logout } from '@mui/icons-material';
import { Avatar, Divider, IconButton, ListItemIcon, Menu, MenuItem, Tooltip, Typography } from '@mui/material';
import { memo, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const AppBarLoggedUser = () => {
  const { instance, accounts } = useMsal();
  const [anchorEl, setAnchorEl] = useState(null);
  const user = useSelector((state) => state.auth);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const signOut = () => {
    const logoutRequest = {
      account: accounts[0],
      postLogoutRedirectUri: '/'
    };
    instance.logoutRedirect(logoutRequest);
  };

  return (
    <div>
      <Tooltip title="Account settings">
        <IconButton onClick={handleMenu} size="small" sx={{ ml: 2 }}>
          <Avatar>{accounts[0].name[0]}</Avatar>
        </IconButton>
      </Tooltip>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0
            }
          }
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        {user.isAdmin && (
          <MenuItem component={Link} to="/users">
            Users
          </MenuItem>
        )}
        {user.isAdmin && (
          <MenuItem component={Link} to="/reports">
            Reports
          </MenuItem>
        )}
        {user.isAdmin && (
          <MenuItem component={Link} to="/access-log">
            Access log
          </MenuItem>
        )}
        {user.isAdmin && <Divider />}
        <MenuItem onClick={() => signOut(instance)}>
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
        </MenuItem>
        <Divider />
        <MenuItem disabled>
          <Typography variant="body2">{accounts[0].name}</Typography>
        </MenuItem>
      </Menu>
    </div>
  );
};

export default memo(AppBarLoggedUser);
