import { memo, useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { AuthenticatedTemplate, UnauthenticatedTemplate, useIsAuthenticated, useMsal } from '@azure/msal-react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { InteractionRequiredAuthError } from '@azure/msal-browser';
import AppBarLoggedUser from './AppBarLoggedUser';
import Login from '../pages/Login';
import { setUser } from '../redux/slices/authUserSlice';
import logo from '../assets/images/logo.png';
import background from '../assets/images/bg-reports.jpg';

const bgImage = `URL(${background})`;

const Layout = () => {
  const [bgStyle, setBgStyle] = useState({ minHeight: '100vh' });
  const isAuthenticated = useIsAuthenticated();
  const dispatch = useDispatch();
  const { instance, accounts, inProgress } = useMsal();
  const [bootsraped, setBootstraped] = useState(false);
  const location = useLocation();
  const user = useSelector((state) => state.auth);

  useEffect(() => {
    if (isAuthenticated && inProgress === 'none' && accounts.length > 0) {
      const tokenRequest = {
        forceRefresh: true,
        account: accounts[0],
        scopes: ['openid']
      };

      instance
        .acquireTokenSilent(tokenRequest)
        .then((response) => {
          if (response.idToken) {
            localStorage.setItem('_wami_', response.idToken);
            dispatch(setUser(accounts[0]));
            setBootstraped(true);
          }

          return null;
        })
        .catch((e) => {
          if (e instanceof InteractionRequiredAuthError) {
            instance.acquireTokenRedirect(tokenRequest);
          }
        });
    }
  }, [isAuthenticated, dispatch, inProgress, accounts, instance]);

  useEffect(() => {
    setBgStyle({
      ...bgStyle,
      backgroundImage: location.pathname === '/reports' ? bgImage : null,
      backgroundSize: 'cover',
      backgroundAttachment: 'fixed',
      display: user.isAdmin ? null : 'flex',
      flexDirection: user.isAdmin ? null : 'column'
    });
  }, [location.pathname, user.isAdmin]);

  return (
    <>
      <UnauthenticatedTemplate>
        <Login />
      </UnauthenticatedTemplate>

      {bootsraped && (
        <AuthenticatedTemplate>
          <div style={bgStyle}>
            <Box sx={{ display: 'flex', marginBottom: 3 }}>
              <MuiAppBar position="relative">
                <Toolbar
                  sx={{
                    pr: '24px' // keep right padding when drawer closed
                  }}
                >
                  <Link to="/" className="d-flex">
                    <img src={logo} alt="wami" height="50" />
                  </Link>
                  <Typography component="h1" variant="h6" color="inherit" noWrap sx={{ flexGrow: 1 }} align="center">
                    Waldorf Astoria Maldives Ithaafushi - BI Portal
                  </Typography>
                  <AppBarLoggedUser />
                </Toolbar>
              </MuiAppBar>
            </Box>
            <Outlet />
          </div>
        </AuthenticatedTemplate>
      )}
    </>
  );
};

export default memo(Layout);
