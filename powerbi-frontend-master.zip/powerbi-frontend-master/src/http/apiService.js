import httpRequest from './request';

const generateReportTokenUrl = (id) => `generate-token/${id}`;
const generateReportUrl = (id) => `report/${id}`;
const generateUserUrl = (id) => `user/${id}`;

const apiService = {
  reports: {
    all: () => httpRequest.get({ url: 'reports' }),
    add: (data) => httpRequest.post({ url: 'report', data }),
    update: (id, data) => httpRequest.put({ url: generateReportUrl(id), data }),
    get: (id) => httpRequest.get({ url: generateReportUrl(id) }),
    fetchOne: (id) => httpRequest.get({ url: generateReportTokenUrl(id) })
  },
  users: {
    all: () => httpRequest.get({ url: 'users' }),
    add: (data) => httpRequest.post({ url: 'user', data }),
    update: (id, data) => httpRequest.put({ url: generateUserUrl(id), data }),
    get: (id) => httpRequest.get({ url: generateUserUrl(id) })
  },
  logs: {
    all: (filters) => httpRequest.get({ url: 'access-logs', data: filters })
  }
};

export default apiService;
