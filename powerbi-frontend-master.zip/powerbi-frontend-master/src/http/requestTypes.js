const REQUEST_METHODS = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT'
};

export default REQUEST_METHODS;
