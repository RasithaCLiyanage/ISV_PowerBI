import axios from 'axios';
import queryString from 'query-string';
import REQUEST_METHODS from './requestTypes';

const BASE_API_URL = `${process.env.REACT_APP_API_URL}`;

const cancelTokenOrigins = {};

axios.interceptors.request.use(
  (config) => {
    const newConfig = { ...config };
    const token = localStorage.getItem('_wami_');
    // eslint-disable-next-line operator-linebreak
    newConfig.headers.Authorization = `Bearer ${token}`;
    return newConfig;
  },
  (error) => Promise.reject(error)
);

// eslint-disable-next-line object-curly-newline
const request = async (method, { url, data = {}, useBase = true, cancelTokenOrigin = '', ...rest }) => {
  const config = { method, ...rest };

  if (cancelTokenOrigin) {
    const prevCancellationToken = cancelTokenOrigins[cancelTokenOrigin];
    if (prevCancellationToken) {
      prevCancellationToken.cancel();
    }

    const cancelToken = axios.CancelToken.source();
    cancelTokenOrigins[cancelTokenOrigin] = cancelToken;
    config.cancelToken = cancelToken.token;
  }

  if (method === REQUEST_METHODS.POST || method === REQUEST_METHODS.PUT) {
    config.data = data;
  }

  if (useBase) {
    config.url = `${BASE_API_URL}${url}`;
  } else {
    config.url = url;
  }

  if (method === REQUEST_METHODS.GET) {
    config.url = queryString.stringifyUrl({ url: config.url, query: data }, { arrayFormat: 'bracket' });
  }

  return axios(config)
    .then((response) => {
      delete cancelTokenOrigins[cancelTokenOrigin];
      return response.data;
    })
    .catch((e) => {
      delete cancelTokenOrigins[cancelTokenOrigin];
      throw e;
    });
};

const httpRequest = {
  get: (config) => request(REQUEST_METHODS.GET, config),
  post: (config) => request(REQUEST_METHODS.POST, config),
  put: (config) => request(REQUEST_METHODS.PUT, config)
};

export default httpRequest;
