import axios from 'axios';

const initInterceptors = () => {
  axios.interceptors.request.use((req) => {
    // eslint-disable-next-line no-param-reassign
    req.headers.authorization = 'barer:asdasd32qedascas';
    return req;
  });
};

export default initInterceptors;
